<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TaskController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/task', function () {
    $data=App\Models\Task::all();
    return view('task')->with('tasks',$data);
});

Route::post('/savetask',[TaskController::class,'insert']);


Route::get('/markascompleted/{id}',[TaskController::class,'uptadetaskcompleted']);

Route::get('/markasnotcompleted/{id}',[TaskController::class,'uptadetasknotcompleted']);

Route::get('/deletetask/{id}',[TaskController::class,'delete']);

Route::get('/updatetask/{id}',[TaskController::class,'update']);

Route::post('/updatedata',[TaskController::class,'updatedata']);

//Route::get('/task',[Test::class,'TaskPageControlle']);
//Route::post('/savetask',[Test::class,'insert']);