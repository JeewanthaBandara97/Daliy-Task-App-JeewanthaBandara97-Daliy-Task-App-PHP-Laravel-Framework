<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;

class TaskController extends Controller
{
    public function insert(Request $request){
      
        //dd($request->all());
        $task=new Task;

        // ----validate erros  ----
        $this->validate($request,['task'=>'required|max:100|min:5',]);

        // ----insert data  ----
        $task->task=$request->task;
        $task->save();

         // ----insert data in to variable ----
        $data=Task::all();
        //dd($data);

        //return redirect()->back();  

        return view('task') -> with('tasks',$data);
      }

     // update iscompleted 
      public function uptadetaskcompleted($id){

        $task=Task::find($id);
        $task->iscompleted=1;
        $task->save();
        return redirect()->back();  
      }

      // update isnotcompleted 
      public function uptadetasknotcompleted($id){

        $task=Task::find($id);
        $task->iscompleted=0;
        $task->save();
        return redirect()->back();  
      }

      // delete 
      public function delete($id){
        $task=Task::find($id);
        $task->delete();
        return redirect()->back();  
      }

      // update view
      public function update($id){
        $task=Task::find($id);
        return view('updatetask')->with('taskdata',$task);
 
      }
       // update data
       public function updatedata(Request $request){
         //dd($request->all());
         $id=$request->id;
         $task=$request->task;
         $data=Task::find($id);
         $data->task=$task;
         $data->save();
         $datas=Task::all();
         return view('task') -> with('tasks',$datas);
 
 
      }     
}
