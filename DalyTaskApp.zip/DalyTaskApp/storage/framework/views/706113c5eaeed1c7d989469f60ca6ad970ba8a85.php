<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/task">Tasks</a>
        </li>
      </ul>
    </div>
  </div>
</nav> 

 <div class="container">
    <div class="text-center">
        <h1>Daily Task</h1>
        <div class="row">
           <div class="col-md-12">
          
          <!-- validate erros print -->
          
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="alert alert-danger" role="alert">
            // <?php echo e($error); ?>

           </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

           <form action="/savetask" method="POST">
            <?php echo e(csrf_field()); ?>

                <input type="text" class="form-control" name="task" placeholder="Enter Your Task">
                <br>
                <input type="submit" class="btn btn-primary" value="Save" name="">
                <input type="submit" class="btn btn-warning" value="Clear" name="">
                <br>
                <br>
           </form>

             <table class="table table-dark">

               <th>ID</th>
               <th>Task</th>
               <th>Completed</th>
               <th>Action</th>

              <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                    <td><?php echo e($task->id); ?></td>
                    <td><?php echo e($task->task); ?></td>
                    <td> 
                    <?php if($task->iscompleted): ?>
                    <button class="btn btn-success">Completed</button>
                    <?php else: ?>
                    <button class="btn btn-warning">Not Completed</button>
                    <?php endif; ?>
                    </td>
                    
                    <td>
                    <?php if(!$task->iscompleted): ?>
                    <a href="/markascompleted/<?php echo e($task->id); ?>" class="btn btn-primary">Mark As completed</a>
                    <?php else: ?>
                    <a href="/markasnotcompleted/<?php echo e($task->id); ?>" class="btn btn-warning">Mark As Notcompleted</a>
                    <?php endif; ?>
                    <a href="/deletetask/<?php echo e($task->id); ?>" class="btn btn-danger">Delete</a>
                    <a href="/updatetask/<?php echo e($task->id); ?>" class="btn btn-secondary">Update Task</a>
                    </td>

               </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
             
             </table>
           </div>
        </div>
    </div>
</div>

</body>
</html><?php /**PATH C:\Users\Jeewantha Bandara\Desktop\Laravel\DalyTaskApp\resources\views/task.blade.php ENDPATH**/ ?>