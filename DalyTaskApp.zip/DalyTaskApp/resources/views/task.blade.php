<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/task">Tasks</a>
        </li>
      </ul>
    </div>
  </div>
</nav> 

 <div class="container">
    <div class="text-center">
        <h1>Daily Task</h1>
        <div class="row">
           <div class="col-md-12">
          
          <!-- validate erros print -->
          
         @foreach($errors->all() as $error)
           <div class="alert alert-danger" role="alert">
            // {{$error}}
           </div>
         @endforeach 

           <form action="/savetask" method="POST">
            {{csrf_field()}}
                <input type="text" class="form-control" name="task" placeholder="Enter Your Task">
                <br>
                <input type="submit" class="btn btn-primary" value="Save" name="">
                <input type="submit" class="btn btn-warning" value="Clear" name="">
                <br>
                <br>
           </form>

             <table class="table table-dark">

               <th>ID</th>
               <th>Task</th>
               <th>Completed</th>
               <th>Action</th>

              @foreach($tasks as $task)
               <tr>
                    <td>{{$task->id}}</td>
                    <td>{{$task->task}}</td>
                    <td> 
                    @if($task->iscompleted)
                    <button class="btn btn-success">Completed</button>
                    @else
                    <button class="btn btn-warning">Not Completed</button>
                    @endif
                    </td>
                    
                    <td>
                    @if(!$task->iscompleted)
                    <a href="/markascompleted/{{$task->id}}" class="btn btn-primary">Mark As completed</a>
                    @else
                    <a href="/markasnotcompleted/{{$task->id}}" class="btn btn-warning">Mark As Notcompleted</a>
                    @endif
                    <a href="/deletetask/{{$task->id}}" class="btn btn-danger">Delete</a>
                    <a href="/updatetask/{{$task->id}}" class="btn btn-secondary">Update Task</a>
                    </td>

               </tr>
              @endforeach 
             
             </table>
           </div>
        </div>
    </div>
</div>

</body>
</html>